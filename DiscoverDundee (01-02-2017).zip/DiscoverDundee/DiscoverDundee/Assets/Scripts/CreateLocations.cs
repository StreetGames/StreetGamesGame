﻿using UnityEngine;
using System.Collections;

public class CreateLocations : MonoBehaviour {

	Vector2 loc_abertay = new Vector2(56.463044F, -2.974081F);
	Vector2 loc_mcmanus = new Vector2(56.462515F, -2.971025F);
	Vector2 loc_dcthompson = new Vector2(56.462091F, -2.972610F);
	Vector2 loc_highschool = new Vector2(56.462773F, -2.972735F);
	Vector2 loc_royalexchange = new Vector2(56.463125F, -2.970704F);

	//To go from latitude to z-coord (latitude-minlatitude)/(latConversion*100(1 unit in pixels))-5.04(halfMapHeight)
	float latConversion = 0.0000060787037037F;
	float minLatitude = 56.457858F;
	float maxLatitude = 56.464423F;

	//To go from longitude to x-coord (longitude-minlongitude)/(lonConversion*100(1 unit in pixels))-9.60(halfMapHeight)
	float lonConversion = 0.000010911979166666F;
	float minLongitude = -2.980929F;
	float maxLongitude = -2.959978F;

	// Use this for initialization
	void Start () {
		Create(loc_abertay.x, loc_abertay.y, "Abertay Univertsity");
		Create(loc_dcthompson.x, loc_dcthompson.y, "DC Thompson");
		Create(loc_highschool.x, loc_highschool.y, "Dundee High School");
		Create(loc_mcmanus.x, loc_mcmanus.y, "McManus Galleries");
		Create(loc_royalexchange.x, loc_royalexchange.y, "Royal Exchange");
	}
	
	// Update is called once per frame
	void Update () {
	
	}

	public void Create(float lat_, float long_, string id_){
		GameObject marker = GameObject.CreatePrimitive (PrimitiveType.Cube);
		marker.transform.position = new Vector3(((long_-minLongitude)/(lonConversion*100)-9.60F),0.25F, ((lat_-minLatitude)/(latConversion*100)-5.04F));
		marker.transform.localScale = new Vector3 (0.1f, 0.5f, 0.1f);
	}
}
